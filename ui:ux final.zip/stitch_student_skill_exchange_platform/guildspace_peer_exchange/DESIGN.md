---
name: Guildspace Peer Exchange
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#464555'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4d44e3'
  primary: '#3525cd'
  on-primary: '#ffffff'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#c3c0ff'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#684000'
  on-tertiary: '#ffffff'
  tertiary-container: '#885500'
  on-tertiary-container: '#ffd4a4'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.03em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '800'
    lineHeight: 38px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.005em
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style

This design system establishes a high-trust, energizing environment where university students and early-career learners exchange tangible skills, collaborate on portfolios, and mentor peers. It merges three critical design philosophies:
- **Discord’s Community Warmth & Live Presence:** Persistent peer indicators, active room avatars, micro-status pings, and low-friction social momentum.
- **LinkedIn’s Credible Identity:** Verified skill modules, peer endorsements, academic institutional tags, and structured portfolio proof.
- **Linear/Notion’s Modular Precision:** Information-dense, crisp 1px borders, atomic metadata chips, keyboard-ready interactions, and meticulous typographical hierarchy without visual noise.

The aesthetic avoids bloated gradients, generic decorative illustrations, and template clutter. Instead, it relies on strict structural framing, tactile badge chips, subtle surface luminance, and focused typography to project clarity, agency, and modern academic competence.

## Colors

The palette is engineered around high-contrast structural utility, semantic role clarity, and accessibility (WCAG AA/AAA compliance across all text tiers):

- **Primary (`#4F46E5` / `#6366F1` Indigo & Electric Iris):** Anchors core actions, navigation states, platform verification badges, and primary interactive nodes.
- **Secondary (`#10B981` / `#059669` Mint & Emerald):** Semantic signal for "Skills Offered", "Ready to Teach", active mentor status, and positive session completions.
- **Tertiary (`#F59E0B` / `#F43F5E` Warm Amber & Coral):** Highlights high-priority matches, learning requests ("Skills Wanted"), incoming collaboration invitations, and live session timers.
- **Neutrals (`#0F172A` Slate 900 to `#F8FAFC` Slate 50):** Deep zinc/slate tones provide ink-like text contrast (`#0F172A`), balanced muted metadata (`#64748B`), delicate interior dividers (`#E2E8F0`), and pure background canvases (`#FFFFFF` surface elevated over `#F8FAFC` platform canvas).

Color is never applied as arbitrary decoration; it functions as a visual routing system distinguishing what a user is learning versus what they are offering.

## Typography

The typographic engine uses **Plus Jakarta Sans** across all primary touchpoints, selected for its crisp geometric terminals, friendly open counters, and legible rendering in dense UI surfaces. 

- **Display & Headlines:** Use tight negative letter spacing (-0.01em to -0.03em) with bold weights (700/800) to project confident identity without feeling sterile.
- **Body Text:** Keeps neutral spacing and generous line heights (1.4–1.5x) for rapid parsing of mentor profiles, project scope briefings, and peer feedback.
- **Labels & Micro-copy:** Optimized for chips, skill capsules, and metadata timestamps. `label-sm` utilizes uppercase rendering with `0.04em` tracking for category groupings.
- **Monospace Accent:** **JetBrains Mono** is reserved exclusively for session IDs, git repository commits, schedule timestamps, and technical skill benchmark metrics.

## Layout & Spacing

The layout is structured on a responsive 12-column modular grid with a strict 4px/8px internal spacing rhythm:
- **Desktop (>= 1280px):** 12-column grid, max-width `1360px`, `gutter: 1.5rem (24px)`, `margin: 2rem (32px)`. Persistent 280px left rail for community navigation and presence pings, flexible center canvas, and modular 360px contextual inspector/activity rail on the right.
- **Tablet (768px - 1279px):** 8-column layout, `gutter: 1.25rem (20px)`, `margin: 1.5rem (24px)`. Right activity panel collapses into an overlay drawer; sidebar condenses to an icon-rail.
- **Mobile (< 768px):** 4-column fluid layout, `gutter: 0.75rem (12px)`, `margin: 1rem (16px)`. Single-column stack with persistent floating micro-bar for active session quick-access.

Component internals adhere strictly to standard gap tokens:
- Use `space-2xs` (4px) and `space-xs` (8px) for badge interiors, inline iconography, and metadata pairings.
- Use `space-sm` (12px) and `space-md` (16px) for card body padding and stacked module rows.
- Use `space-lg` (24px) and `space-xl` (32px) for segment headers and cross-card structural boundaries.

## Elevation & Depth

Visual hierarchy prioritizes **tonal layering and low-contrast perimeter definition** over heavy drop shadows:

1. **Base Platform (`Level 0`):** Canvas color `#F8FAFC` (Slate 50). Completely flat, non-interactive foundation.
2. **Modular Container Surfaces (`Level 1`):** Pure `#FFFFFF` (White) backed by a crisp 1px solid border (`#E2E8F0` / Slate 200). Shadow is feather-light: `0 1px 3px 0 rgba(15, 23, 42, 0.04)`.
3. **Interactive & Hover Cards (`Level 2`):** Elevates on interaction using an ambient Indigo-tinted shadow: `0 8px 24px -4px rgba(79, 70, 229, 0.08), 0 2px 6px -1px rgba(15, 23, 42, 0.04)`, with border transitioning to `#CBD5E1`.
4. **Floating Action Sheets & Flyouts (`Level 3`):** Drawers, match modals, and schedule selectors utilize crisp borders paired with diffuse depth: `0 20px 32px -8px rgba(15, 23, 42, 0.12), 0 4px 12px -2px rgba(15, 23, 42, 0.06)`.
5. **Presence Glow & Active Pings:** Active online mentors or live pair sessions use a subtle ambient pulse: a dual-ring highlight (`ring-2 ring-emerald-500/20`) rather than blurred drop-glows, keeping interfaces sharp and focused.

## Shapes

The design system employs a **Rounded (Level 2)** geometry balance:
- **Cards & Primary Modules:** Use `rounded-2xl` (16px / `1rem`) to project modern approachability and community warmth without ballooning into excessive toy-like curvature.
- **Inner Nested Blocks & Media Previewers:** Step down to `rounded-xl` (12px / `0.75rem`) to maintain proportional concentric nesting inside parent containers.
- **Buttons, Inputs, & Form Elements:** Use `rounded-lg` (8px / `0.5rem`) for crisp architectural alignment with text baselines.
- **Chips, Badges, & Presence Dots:** Fully pill-shaped (`rounded-full` / 9999px) to communicate atomic, non-editable tag status and tactile tap targets.

## Components

### Buttons
- **Primary:** Solid `#4F46E5` fill, `#FFFFFF` text, `rounded-lg` (8px), height 40px (desktop) / 44px (mobile), font weight 600 (`label-md`). Hover transitions to `#4338CA` with subtle `0 1px 2px rgba(79, 70, 229, 0.2)` shadow. Active state depresses 1px (`translate-y-[0.5px]`).
- **Secondary (Skill Action):** Mint tone for offering sessions. `#ECFDF5` surface with `#047857` label, `#A7F3D0` crisp border. Hover intensifies to `#D1FAE5`.
- **Tertiary / Ghost:** Transparent background, `#475569` text, `border-transparent`. Hover shifts to `#F1F5F9` background and `#0F172A` text.
- **Icon Button:** Strictly 36x36px or 40x40px square with centered SVGs, bordered with `#E2E8F0` on white.

### Chips & Skill Badges
- **Teaching/Skill Offered Chip:** Emerald-tinted `#F0FDF4` background, `#166534` text, `#BBF7D0` 1px border. Prefixed with a mini filled dot (`#10B981`) or checkmark icon.
- **Learning/Skill Wanted Chip:** Amber-tinted `#FFFBEB` background, `#B45309` text, `#FDE68A` 1px border.
- **Institutional / Credential Badge:** Slate `#F1F5F9` background, `#334155` text, `#E2E8F0` border. Includes university or domain SVG insignia at 12x12px.
- **Interactive Filter Chip:** Pill-shaped (`rounded-full`), toggleable between neutral inactive (`#FFFFFF` with `#E2E8F0` border) and active (`#EEF2FF` with `#6366F1` border and `#4338CA` text).

### Cards (Modular Skill Cards)
- Encased in `rounded-2xl` with a mandatory `1px solid #E2E8F0` outline and pure white surface.
- **Header Slot:** Mentee/Mentor avatar with presence status ring, display name, university affiliation tag, and match percentage score chip on the top right.
- **Content Slot:** Clear 2-column micro-grid: Left column lists "Teaching" chips; right column lists "Learning" chips.
- **Footer Slot:** Direct actions: "Quick Connect" button and "View Proof/Portfolio" link, separated from content with an inner divider `#F1F5F9`.

### Input Fields & Controls
- **Text Inputs:** Height 42px, `rounded-lg` (8px), `#FFFFFF` surface, `1px solid #CBD5E1`. Placeholder `#94A3B8`. Focus state introduces a clean 2px offset ring: `ring-2 ring-indigo-500/20 border-indigo-600`.
- **Search Bar with Omnisearch:** Integrated keyboard shortcut indicator (`⌘K` rendered in JetBrains Mono badge on the trailing edge).
- **Checkboxes & Radios:** 18x18px box with `rounded-md` (checkbox) or `rounded-full` (radio). `#4F46E5` fill when selected with crisp white checkmark vector; `#CBD5E1` border in inactive resting state.

### Lists & Activity Feeds
- Compact item rows divided by `#F1F5F9` hair lines. No heavy container nesting.
- Presence indicator embedded on avatar edges: 8px solid emerald dot with a 2px white halo for active students; subtle amber dot for "In Session".
- Session booking slots rendered as calendar pill chips with interactive hover highlights.